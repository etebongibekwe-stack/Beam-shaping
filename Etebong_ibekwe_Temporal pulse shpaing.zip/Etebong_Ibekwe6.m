clear;              % Remove all variables from workspace
clc;                % Clear command window
close all;          % Close all open figures

%% 1. Sampling frequencies
N = 8000;            % Total number of time samples
fs = 5000;           % Sampling frequency in Hz
t = (-N/2:N/2-1)/fs; % Time vector centered at t = 0 (seconds)

df = fs/N;           % Frequency resolution (Hz)
f = (-N/2:N/2-1)*df; % Frequency axis centered at f = 0 (Hz)

%% 2. Gaussian weight distribution
f0 = 800;           % Central (carrier) frequency in Hz
BW = 100;           % Spectral bandwidth in Hz
M = 41;              % Number of discrete frequency components

% Generate M equally spaced frequencies within the bandwidth
freqs = linspace(f0-BW/2, f0+BW/2, M);

% Standard deviation of the Gaussian spectrum
sigma_f = BW/4;

% Gaussian spectral amplitude weights
weights = exp(-(freqs - f0).^2 / (2 * sigma_f^2));

% Plot Gaussian spectral weights
figure;
plot(freqs, weights, 'r', 'LineWidth', 1.5); % Plot Gaussian envelope
title('Gaussian weights');                  % Plot title
xlabel('Frequency (Hz)');                   % X-axis label
ylabel('Amplitude');                        % Y-axis label
grid on;                                    % Enable grid

%% 3. Summing the fields (Time Domain)
Ec = zeros(size(t));  % Initialize total electric field to zero

% Sum all frequency components with Gaussian weighting
for n = 1:M
    % Add cosine wave at frequency freqs(n) weighted by Gaussian amplitude
    Ec = Ec + weights(n) * cos(2 * pi * freqs(n) * t);
end

% Plot resulting time-domain electric field
figure;
plot(t, Ec, 'b');      % Plot electric field versus time
title('Interference of Multiple Frequencies (Gaussian Pulse)');
xlabel('Time (s)');    % X-axis label
ylabel('Amplitude');  % Y-axis label
axis([-0.1 0.1 min(Ec)*1.1 max(Ec)*1.1]); % Zoom and scale axes
grid on;               % Enable grid

%% 4. FFT to Frequency Domain
Ec_fft = fft(Ec);                  % Compute FFT of time-domain signal
Ec_fft = fftshift(Ec_fft);         % Shift zero frequency to center
Ec_fft = abs(Ec_fft);              % Take magnitude of spectrum
Ec_fft = Ec_fft / max(Ec_fft);     % Normalize spectral amplitude

% Plot frequency-domain spectrum
figure;
plot(f, Ec_fft);                   % Plot spectrum versus frequency
title('Frequency Domain (Gaussian Envelope)');
xlabel('Frequency (Hz)');          % X-axis label
ylabel('|X(f)|');                  % Y-axis label
xlim([400 1200]);                  % Limit plot to spectral bandwidth
grid on;                           % Enable grid
%% 5
Ecf = fftshift(fft(Ec));
figure;
plot(f,abs(Ecf), 'LineWidth',1.5);
xlabel('Frequency(Hz)');
ylabel('|Ecf(f)|');
title('Frequency Domain: Gaussian Envelope(Laser Spectrum)');
grid on;
xlim([400 1200])



