clear; clc; close all;

%% 1. GLOBAL SIMULATION PARAMETERS
N = 8192;               
time_window = 4000e-15; 
dt = time_window / N;   
fs_rate = 1/dt;         
t = (-N/2:N/2-1)*dt;    
df = fs_rate/N;         
f = (-N/2:N/2-1)*df;   
w = 2 * pi * f;         

%% 2. INITIAL PULSE DEFINITION
tau0 = 30e-15;          %  fs
% Generate Gaussian Pulse in time domain
Ec = exp(-2*log(2) * (t.^2) / tau0^2);
% Transform to Frequency Domain
Ecf = fftshift(fft(Ec)); 

%% 3. DEFINE DISPERSION STRENGTHS
% I chose arbitrary numbers to check the effect of the order
GD_fs   = 150;          % 1st Order: 150 fs shift
GDD_fs2 = 2000;         % 2nd Order: 2000 fs^2 
TOD_fs3 = 30000;        % 3rd Order: 30000 fs^3 

titles = {'1st Order: Group Delay (Time Shift)', ...
          '2nd Order: GDD (Pulse Broadening)', ...
          '3rd Order: TOD (Asymmetric Distortion)'};

figure('Name', 'Individual Dispersion Analysis', 'Position', [100, 100, 800, 900]);

% 4. LOOP THROUGH DISPERSION ORDERS
for order = 1:3
    % Initialize phase
    switch order
        case 1
            % Phase = GD * w
            phi = GD_fs * (1e-15) * w;
        case 2
            % Phase = 1/2 * GDD * w^2
            phi = 0.5 * GDD_fs2 * (1e-15^2) * w.^2;
        case 3
            % Phase = 1/6 * TOD * w^3
            phi = (1/6) * TOD_fs3 * (1e-15^3) * w.^3;
    end
    
    % Apply the complex phase shift in the frequency domain
    Ecf_dispersed = Ecf .* exp(1i * phi);
    
    % Transform back to Time Domain
    E_out = ifft(ifftshift(Ecf_dispersed));
    
    % --- PLOTTING ---
    subplot(3, 1, order);
    plot(t*1e15, abs(Ec), 'k--', 'LineWidth', 1); hold on; % Original Pulse
    plot(t*1e15, abs(E_out), 'b', 'LineWidth', 1.5);      % Dispersed Pulse
    
    title(titles{order});
    xlabel('Time (fs)');
    ylabel('Amplitude');
    xlim([-400 400]); % View range
    grid on;
    if order == 1, legend('Original 50fs','Modified'); end
end

%% 3. Effect of GDD
% I modify this code to check the effect of the dispersion of different
% medium
GDD_fs2 = 287.70;          
GDD1_fs2 = 332.755;         
GDD2_fs2 = 351.86;        
GDD3_fs2 = 843.30;
titles = {'GDD Fused silica(Pulse Broadening)', ...
          'GDD Fused Quartz(Pulse Broadening)', ...
          'GDD Fused Bk7 (Pulse Broadening)'...
          'GDD Fused ZnS (Pulse Broadening)'};

% 4. LOOP THROUGH DISPERSION ORDERS
for order = 1:4
    % Initialize phase
    switch order
        case 1
            % Phase = GD * w
            phi = 0.5 * GDD_fs2 * (1e-15^2) * w.^2;
        case 2
            % Phase = 1/2 * GDD * w^2
            phi = 0.5 * GDD1_fs2 * (1e-15^2) * w.^2;
        case 3
            % Phase = 1/6 * TOD * w^3
           phi = 0.5 * GDD2_fs2 * (1e-15^2) * w.^2;
        case 4
            phi = 0.5 * GDD3_fs2 * (1e-15^2) * w.^2;
    end
    
    % Apply the complex phase shift in the frequency domain
  
    Ecf_dispersed = Ecf .* exp(1i * phi);
    % Transform back to Time Domain
    E_out = ifft(ifftshift(Ecf_dispersed));
      subplot(4, 1, order);
    plot(t*1e15, abs(Ec), 'k--', 'LineWidth', 1); hold on; % Original Pulse
    plot(t*1e15, abs(E_out), 'b', 'LineWidth', 1.5);      % Dispersed Pulse
    
    title(titles{order});
    xlabel('Time (fs)');
    ylabel('Amplitude');
    xlim([-400 400]); % View range
    grid on;
    if order == 1, legend('Original 50fs','Modified'); end
      
end