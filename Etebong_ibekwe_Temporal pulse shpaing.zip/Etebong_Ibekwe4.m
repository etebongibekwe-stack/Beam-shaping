clear; clc; close all;

%%  PARAMETERS 
lambda = 800e-9;     % Wavelength [m]
L = 10e-3;           % Physical grid size [m]
N = 1024;            % Number of samples
dx = L/N;
n =1.5;
z1 = 10e-3;            % Propagation distance to aperture [m]
f  = 200e-3;           % Lens focal length [m]
z2 = f;              % Distance after lens [m]
x = (-N/2:N/2-1)*dx; % since dx and dy have same dimension
[X,Y] = meshgrid(x,x);
R = sqrt(X.^2 + Y.^2);
z_max = R./(n-1).*R;

%%  GAUSSIAN BEAM 
w0 = 1e-3;           % Beam waist [m]
u0 = exp(-(R.^2)/(w0^2));
figure;
imagesc(x*1e3,x*1e3,abs(u0).^2);
axis square; colormap hot; colorbar;
title('Initial Gaussian Beam');

%% 4. PROPAGATE TO APERTURE
u1 = propTF(u0,L,lambda,z1);

%% 5. CIRCULAR APERTURE
ap_radius = 0.5e-3;  % Aperture radius [m]
aperture = double(R <= ap_radius);
u2 = u1 .* aperture;
figure;
imagesc(x*1e3,x*1e3,abs(u2).^2);
axis square; colormap hot; colorbar;
title('After Circular Aperture');

%% 6. THIN LENS 
lens = exp(-1i*pi/(lambda*f)*(X.^2 + Y.^2));
u3 = u1 .* lens;
%% Propagation after thin lens
u4 = propTF(u3,L,lambda,z1);
figure;
imagesc(x*1e3,x*1e3,angle(u4).^2);
axis square; colormap hot; colorbar;
title('Field After Lens Focal Plane at z=', z2);

%% Propagation through axicon
n = 1.5;
alpha = deg2rad(0.5);
k = 2*pi/lambda;
phi = -k*(n-1).*R.*alpha;
u5 = u1.*exp(-1i*phi);
figure;
imagesc(x*1e3,x*1e3,abs(u5).^2);
axis square; colormap hot; colorbar;
title('Field After axicon Lens Focal Plane at z=', z2);
%% Propagation after axicon
u6 = propTF(u5,L,lambda,z2);
figure;
imagesc(x*1e3,x*1e3,angle(u6).^2);
axis square; colormap hot; colorbar;
title('Field After axicon Lens Focal Plane at z=', z2);
%% Propagation Function

function u2 = propTF(u1,L,lambda,z)

    [N,~] = size(u1);
    dx = L/N;

    fx = (-N/2:N/2-1)/L;
    [FX,FY] = meshgrid(fx,fx);

    H = exp(-1i*pi*lambda*z*(FX.^2 + FY.^2));
    H = fftshift(H);

    U1 = fft2(fftshift(u1));
    U2 = H .* U1;

    u2 = ifftshift(ifft2(U2));
end
