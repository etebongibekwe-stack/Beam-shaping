clear; clc; close all;
%% STEP 1: Setup Femtosecond Scale Simulation
N = 8192; 
time_window = 4000e-15; 
dt = time_window / N; 
fs_rate = 1/dt; 
t = (-N/2:N/2-1)*dt; 
%% Calculation of T_out
tau0 = [8 40 100 200 500 1000]; % Initial Pulse Width (fs)
GVD =  168.66; %fs2/mm
GDD = GVD*5; 
T_out = [];
for i = 1:length(tau0)
  T_out(end+1) = tau0(i)*sqrt(1+4*log(2)*GDD/tau0(i)^2)
end

%% STEP 2: Create Initial Gaussian Pulse 
% Gaussian Envelope formula for Amplitude
tau0=40*1e-15
Ec = exp(-2*log(2) * (t.^2) / tau0^2);

%% STEP 3: FFT to Frequency Domain
Ecf = fftshift(fft(Ec)); % FFT
df = fs_rate/N; % 
f = (-N/2:N/2-1)*df; 
w = 2 * pi * f; 
%% STEP 4: Apply GDD List and Loop
GDD_values_fs2 = [287.70 351.86 843.30 455.875]; % I computed from refractive index.info
material = {'Fused silica' 'Bk7' 'ZnS' 'Saphire'};
colors = {'r', 'g', 'm', 'c'}; % Colors for plotting
figure;
hold on;
% Plot the original pulse first (Black dashed)
plot(t*1e15, abs(Ec), 'k--', 'LineWidth', 2);
legend_entries = {'Original Pulse (200fs)'};
fprintf('Processing GDD values...\n');
for k = 1:length(GDD_values_fs2)
current_GDD_fs2 = GDD_values_fs2(k);
% 1. Convert GDD from fs^2 to SI units (s^2)
% 1 fs = 1e-15 s, so 1 fs^2 = 1e-30 s^2
GDD_SI = current_GDD_fs2 * (1e-15)^2;
% 2. Apply Dispersion Phase: exp( i * GDD * w^2 / 2 )
Phase_Factor = exp(1i * (GDD_SI * w.^2) / 2);
Ecf_dispersed = Ecf .* Phase_Factor;
% 3. Inverse FFT to get back to time
E_out = ifft(ifftshift(Ecf_dispersed));
% 4. Plot
plot(t*1e15, abs(E_out), 'Color', colors{k}, 'LineWidth', 1.5);
% Add to legend
legend_entries{end+1} = material{k};
% Print broadening info
[~, idx] = max(abs(E_out)); % Find peak
fprintf('GDD: %3d fs^2 applied.\n', current_GDD_fs2);
end

%% Graph Formatting
hold off;
xlabel('Time (femtoseconds)');
ylabel('Normalized Amplitude');
title('Pulse Broadening for Different GDD Values of dispersive medium');
legend(legend_entries);
grid on;
xlim([-300 300]); % Zoom in to see the pulses clearly
%% 1. Define the Data Columns
T_in = [8; 40; 100; 200; 500; 1000]; % I chose to drop from 500 since the do not have much effect so that the dispersion from the smaller initial value can be seen clearly in the report

% Output pulse durations (fs) I computed this table from the equation that
% you gave to us.
T_out_SiO2    = [29.40; 49.00; 103.90; 202.00; 500.80; 1000.40];
T_out_Sapphire = [36.40; 53.50; 106.10; 203.10; 501.30; 1000.60];
T_out_BK7     = [32.20; 50.80; 104.80; 202.40; 501.00; 1000.50];
T_out_ZnS     = [49.00; 62.80; 111.11; 205.80; 502.30; 1001.20];



% 2. Create the MATLAB Table
ResultsTable = table(T_in, T_out_SiO2, T_out_Sapphire, T_out_BK7, T_out_ZnS);


% 4. Plotting the Comparison (Visualization)
figure;
hold on;
plot(T_in, T_out_SiO2, '-o', 'LineWidth',1.5, 'DisplayName', 'SiO2');
plot(T_in, T_out_Sapphire, '-s', 'LineWidth',1.5,'DisplayName', 'Quartz');
plot(T_in, T_out_BK7, '-^', 'LineWidth',1.5,'DisplayName', 'Bk7');
plot(T_in, T_out_ZnS, '-d', 'LineWidth',1.5,'DisplayName', 'ZnS');
plot(T_in, T_in, 'k--', 'LineWidth',1.5,'DisplayName', 'No Dispersion'); % Reference line

xlabel('Input Pulse Width T_{in} (fs)');
ylabel('Output Pulse Width T_{out} (fs)');
title('Comparison of Pulse Broadening across Materials');
legend('Location', 'northwest');
grid on;