clear; close all; clc;

%% Physical Parameters
lambda = 800e-9;              % Wavelength (m)
k = 2*pi/lambda;
w0 = 1e-3;                    % Beam waist (m) I chose 1 to size my window when I chose 2 it was not okay
l = 0;                        
m = 0;                        
z_LG = 0;                    

N = 2048;                     
L = 8e-3;                    
dx = L/N;
x = (-N/2:N/2-1)*dx;
[X,Y] = meshgrid(x,x);
R = sqrt(X.^2 + Y.^2);
f1 = 0.5;                     % Lens f1 (m)
f2 = 0.5;                     % Lens f2 (m)
axicon_angle = 0.5*pi/180;    % Axicon cone angle (rad)
n_ax = 1.45;                  % Axicon refractive index


%% Input LG Beam 
U0 = LG_beam(l, m, w0, lambda, z_LG, X, Y);
U0 = U0 / max(abs(U0(:)));    % Normalize
figure;
imagesc(x*1e3,x*1e3,abs(U0).^2);
axis square; colormap hot; colorbar;
title('LG Beam');
%%  Axicon Phase 
axicon = exp(1i*k*(n_ax-1)*axicon_angle*R);
U1 = U0 .* axicon;
figure;
imagesc(x*1e3,x*1e3,angle(U1).^2);
axis square; colormap hot; colorbar;
title('LG Axicon phase');

%% Propagation to lens 1
 U2 = propTF(U1,L,lambda,f1);
 lens = exp(-1i*pi/(lambda*f2)*(X.^2+Y.^2));
 U3 = U2.*lens;
 
figure;
imagesc(x*1e3,x*1e3,angle(lens));
axis square; colormap hot; colorbar;
title('LG after axicon f1=',f1);


%% Propagation to Annular Aperture
 U4 = propTF(U3,L,lambda,f1);
R_inner = 0.5e-3; % Inner radius of the ring mask (adjust based on your f1)
R_outer = 3e-3; % Outer radius of the ring mask
annular_mask = (R >= R_inner) & (R <= R_outer);
U5 = U4.*annular_mask;
figure;
imagesc(x*1e3,x*1e3,abs(annular_mask));
axis square; colormap hot; colorbar;
title('Aafter lensf1 =',f1);
%% Propagation to lens 2
 U6 = propTF(U5,L,lambda,f2);
 lens = exp(-1i*pi/(lambda*f2)*(X.^2+Y.^2));
 U7 = U6.*lens;
figure;
imagesc(x*1e3,x*1e3,abs(U6).^2);
axis square; colormap hot; colorbar;
title('Afetr annular mask f2 =', f2);
 %% Propagation to image plane
 U8 = propTF(U7,L,lambda,f2);
figure;
imagesc(x*1e3,x*1e3,abs(U8).^2);
axis square; colormap hot; colorbar;
title('After Lens 2 f2 =', f2);
%% I redefine f2=200 mm
f3 = 200e-3;
%% Propagation to lens 2
 U6 = propTF(U5,L,lambda,f3);
 lens = exp(-1i*pi/(lambda*f2)*(X.^2+Y.^2));
 U7 = U6.*lens;
figure;
imagesc(x*1e3,x*1e3,abs(U6).^2);
axis square; colormap hot; colorbar;
title('Afetr annular mask f2 =', f3);
 %% Propagation to image plane
U8 = propTF(U7,L,lambda,f3);
figure;
imagesc(x*1e3,x*1e3,abs(U8).^2);
axis square; colormap hot; colorbar;
title('After Lens 2 f2 =', f3);
%% Laguerrer function Laguerrer 
function U = LG_beam(l, m, w0, lambda, z, X, Y)

k = 2*pi/lambda;
rho = sqrt(X.^2 + Y.^2);
phi = atan2(Y, X);

zR = pi*w0^2/lambda;
wz = w0 * sqrt(1 + (z/zR)^2);
zeta = atan(z/zR);

if z == 0
    Rz = Inf;
else
    Rz = z * (1 + (zR/z)^2);
end

alpha = abs(l);
x = 2*rho.^2./wz.^2;

L = zeros(size(x));
for k_idx = 0:m
    coeff = (-1)^k_idx * factorial(m+alpha) / ...
           (factorial(m-k_idx)*factorial(alpha+k_idx)*factorial(k_idx));
    L = L + coeff * x.^k_idx;
end

A = sqrt(2*factorial(m)/(pi*factorial(m+abs(l)))) / w0;
U = A .* (w0./wz) ...
    .* (sqrt(2)*rho./wz).^abs(l) ...
    .* L ...
    .* exp(-rho.^2./wz.^2) ...
    .* exp(-1i*k*z) ...
    .* exp(-1i*k*rho.^2./(2*Rz)) ...
    .* exp(1i*l*phi) ...
    .* exp(1i*(2*m + abs(l) + 1)*zeta);

end
%% Propagation Function from class work

function u2 = propTF(u1,L,lambda,z)

    [N,~] = size(u1);
    dx = L/N;

    fx = (-N/2:N/2-1)/L;
    [FX,FY] = meshgrid(fx,fx);

    H = exp(-1i*pi*lambda*z*(FX.^2 + FY.^2));
    H = fftshift(H);

    U1 = fft2(fftshift(u1));
    U2 = H .* U1;

    u2 = ifftshift(ifft2(U2));
end